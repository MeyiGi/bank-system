package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import services.MoneyTransfer;
import services.TransferByAccountNumber;
import services.TransferByInnNumber;
import services.TransferByPhoneNumber;
import database.CSVClientRepository;

import java.awt.*;

public class TransactionView extends JDialog {
    private static final String PHONE_NUMBER_METHOD = "Phone Number";
    private static final String ACCOUNT_NUMBER_METHOD = "Account Number";
    private static final String INN_NUMBER_METHOD = "Inn Number";

    private final JComboBox<String> methodComboBox;
    private final JTextField senderField;
    private final JTextField recipientField;
    private final JTextField amountField;
    private boolean confirmed;
    private final CSVClientRepository clientRepository;

    public TransactionView(JFrame parent, CSVClientRepository clientRepository) {
        super(parent, "Make Transaction", true);
        this.clientRepository = clientRepository;

        // Main panel with padding and title
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Transaction Details", TitledBorder.LEFT, TitledBorder.TOP));

        // Form panel with GridBagLayout for component alignment
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        methodComboBox = new JComboBox<>(new String[]{PHONE_NUMBER_METHOD, ACCOUNT_NUMBER_METHOD, INN_NUMBER_METHOD});
        senderField = new JTextField(15);
        recipientField = new JTextField(15);
        amountField = new JTextField(15);

        // Building the form
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Method:"), gbc);
        gbc.gridx = 1;
        formPanel.add(methodComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Sender:"), gbc);
        gbc.gridx = 1;
        formPanel.add(senderField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Recipient:"), gbc);
        gbc.gridx = 1;
        formPanel.add(recipientField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Amount:"), gbc);
        gbc.gridx = 1;
        formPanel.add(amountField, gbc);

        // Button panel
        JPanel buttonPanel = new JPanel();
        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        // Adding panels to main panel
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Setting up the dialog
        setContentPane(mainPanel);

        // Button event listeners
        okButton.addActionListener(e -> {
            confirmed = true;
            setVisible(false);
        });

        cancelButton.addActionListener(e -> {
            confirmed = false;
            setVisible(false);
        });

        pack();
        setLocationRelativeTo(parent);
    }

    public TransactionData getTransactionData() {
        String method = (String) methodComboBox.getSelectedItem();
        
        // Select the strategy directly based on method using a helper function
        MoneyTransfer strategy = createTransferStrategy(method);
        
        return new TransactionData(
            senderField.getText(),
            recipientField.getText(),
            Double.parseDouble(amountField.getText()),
            strategy  // Directly pass strategy
        );
    }

    private MoneyTransfer createTransferStrategy(String method) {
        switch (method) {
            case PHONE_NUMBER_METHOD:
                return new TransferByPhoneNumber(clientRepository);
            case ACCOUNT_NUMBER_METHOD:
                return new TransferByAccountNumber(clientRepository);
            case INN_NUMBER_METHOD:
                return new TransferByInnNumber(clientRepository);
            default:
                throw new IllegalArgumentException("Unknown method: " + method);
        }
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public static class TransactionData {
        public final String sender;
        public final String recipient;
        public final double amount;
        public final MoneyTransfer strategy;

        public TransactionData(String sender, String recipient, double amount, MoneyTransfer strategy) {
            this.sender = sender;
            this.recipient = recipient;
            this.amount = amount;
            this.strategy = strategy;
        }
    }
}
